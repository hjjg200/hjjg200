## 0.2.0 - Auto Opaque
* Adds an option for a more opaque background that switches automatically between light and dark themes.

## 0.1.3 - Git Gutter
* Fix git gutter

## 0.1.2 - Atom version
* Limit Atom version to `1.19.0`

## 0.1.1 - Docs
* Update README

## 0.1.0 - First Release
* Every feature added
* Every bug fixed
